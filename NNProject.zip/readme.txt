To run this project: 
You will need to have numpy and sklearn and Tensorflow. 

To run the project you simply need to navigate to this folder and use the command:
python3 project.py
